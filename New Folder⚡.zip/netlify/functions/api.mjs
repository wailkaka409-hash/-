import crypto from "node:crypto";

const headers = {
  "Content-Type": "application/json; charset=utf-8",
  "Cache-Control": "no-store",
  "Access-Control-Allow-Origin": process.env.SITE_ORIGIN || "*",
  "Access-Control-Allow-Headers": "Content-Type, x-member-token, x-admin-password",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Vary": "Origin"
};
const json = (status, data) => new Response(JSON.stringify(data), { status, headers });
const allowedBanners = new Set(["basic", "team-red", "team-elite", "team-gold"]);
const supabaseUrl = () => (process.env.SUPABASE_URL || "").replace(/\/$/, "");
const serviceKey = () => process.env.SUPABASE_SERVICE_ROLE_KEY || "";
function configReady() { return Boolean(supabaseUrl() && serviceKey() && process.env.ADMIN_PASSWORD); }
async function db(path, options = {}) {
  const response = await fetch(`${supabaseUrl()}/rest/v1/${path}`, {
    ...options,
    headers: {
      "apikey": serviceKey(),
      "Authorization": `Bearer ${serviceKey()}`,
      "Content-Type": "application/json",
      "Accept": "application/json",
      ...(options.headers || {})
    }
  });
  const text = await response.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = { message: text }; }
  if (!response.ok) throw new Error(data?.message || data?.hint || "خطأ في قاعدة البيانات");
  return data;
}
const sha = value => crypto.createHash("sha256").update(value).digest("hex");
function safeEqual(a, b) {
  const aa = Buffer.from(String(a || ""));
  const bb = Buffer.from(String(b || ""));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function validNickname(value) {
  const name = String(value || "").trim();
  return name.length >= 2 && name.length <= 24 && /^[\p{L}\p{N}_ .-]+$/u.test(name);
}
async function getMember(token) {
  if (!token || token.length < 32 || token.length > 200) return null;
  const rows = await db(`members?token_hash=eq.${encodeURIComponent(sha(token))}&select=id,nickname,banner_id,created_at&limit=1`);
  return rows?.[0] || null;
}
export default async (request) => {
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers });
  if (request.method !== "POST") return json(405, { error: "الطريقة غير مدعومة." });
  if (!configReady()) return json(503, { error: "لم يكتمل إعداد الخادم بعد. راجع ملف README-AR.txt." });
  const url = new URL(request.url);
  const action = url.searchParams.get("action") || "";
  let body = {};
  try { body = await request.json(); } catch { return json(400, { error: "البيانات المرسلة غير صحيحة." }); }

  try {
    if (action === "register") {
      const nickname = String(body.nickname || "").trim();
      if (!validNickname(nickname)) return json(400, { error: "اكتب اسمًا من حرفين إلى 24 حرفًا، دون رموز غير مسموحة." });
      const token = crypto.randomBytes(32).toString("base64url");
      const rows = await db("members?select=id,nickname,banner_id,created_at", {
        method: "POST",
        headers: { "Prefer": "return=representation" },
        body: JSON.stringify({ nickname, token_hash: sha(token), banner_id: "basic" })
      });
      return json(201, { token, member: rows[0] });
    }
    if (action === "profile") {
      const member = await getMember(request.headers.get("x-member-token"));
      if (!member) return json(401, { error: "لم يتم العثور على هذا الملف. اختر اسمك من جديد." });
      return json(200, { member });
    }
    if (action.startsWith("admin-")) {
      if (!safeEqual(request.headers.get("x-admin-password"), process.env.ADMIN_PASSWORD)) return json(401, { error: "كلمة مرور الإدارة غير صحيحة." });
      if (action === "admin-list") {
        const members = await db("members?select=id,nickname,banner_id,created_at&order=created_at.desc&limit=500");
        return json(200, { members });
      }
      if (action === "admin-assign") {
        const memberId = String(body.member_id || "");
        const bannerId = String(body.banner_id || "");
        if (!/^[0-9a-f-]{36}$/i.test(memberId) || !allowedBanners.has(bannerId)) return json(400, { error: "اختيار العضو أو البنر غير صحيح." });
        const rows = await db(`members?id=eq.${encodeURIComponent(memberId)}&select=id,nickname,banner_id`, {
          method: "PATCH", headers: { "Prefer": "return=representation" }, body: JSON.stringify({ banner_id: bannerId })
        });
        if (!rows?.length) return json(404, { error: "لم يتم العثور على العضو." });
        return json(200, { member: rows[0] });
      }
      return json(404, { error: "طلب إدارة غير معروف." });
    }
    return json(404, { error: "الطلب غير معروف." });
  } catch (error) {
    return json(500, { error: "حدث خطأ في الخادم. تحقق من إعداد قاعدة البيانات." });
  }
};
